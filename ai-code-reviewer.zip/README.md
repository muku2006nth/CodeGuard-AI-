# AI Code Reviewer

AI-powered code vulnerability detector: fine-tuned **CodeBERT** on [DetectVul/devign](https://huggingface.co/datasets/DetectVul/devign), **RAG** over OWASP + CVE (ChromaDB), and **LLaMA3** fix generation via Groq.

Paste code or a GitHub file URL → vulnerability type, severity, CVE references, and a suggested fix in under ~8 seconds.

## Local PC vs Google Colab

| Environment | Use for |
|-------------|---------|
| **Local PC** (CUDA optional) | Development, dataset inspect, RAG, API, Streamlit |
| **Google Colab T4** | CodeBERT training only (~3–5 hrs) |

Training the full dataset on CPU is blocked in `src/train.py`. Use **[colab/train_codebert.ipynb](colab/train_codebert.ipynb)**.

→ Full guide: **[docs/WORKFLOW.md](docs/WORKFLOW.md)**

## Training workflow

```
Hugging Face DetectVul/devign
        ↓
   src/train.py  (Colab T4)
        ↓
 models/codebert-vuln/
```

No CSV downloads. No `train.json`. The dataset loads via `datasets.load_dataset("DetectVul/devign")`.

## Architecture

```
User Input (paste / GitHub / upload)
    → CodeBERT Classifier (vulnerable vs safe)
    → ChromaDB RAG (OWASP + CVE context)
    → LLaMA3 via Groq (fix + explanation)
    → Streamlit UI / FastAPI JSON
```

## Tech stack

| Layer | Tool |
|-------|------|
| Dataset | [DetectVul/devign](https://huggingface.co/datasets/DetectVul/devign) on Hugging Face |
| Classifier | `microsoft/codebert-base` (fine-tuned) |
| Vector DB | ChromaDB + `all-MiniLM-L6-v2` |
| LLM | LLaMA 3.3 70B via Groq |
| API | FastAPI |
| UI | Streamlit |

## Quick start — local development (no GPU)

```powershell
cd ai-code-reviewer
python -m venv .venv
.\.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
python scripts\inspect_dataset.py
python scripts\verify_local_dev.py
python src\ingest.py --seed-only
streamlit run app\streamlit_app.py
```

API:

```powershell
uvicorn api.main:app --reload --port 8000
```

## Project layout

- `src/devign_data.py` — Hugging Face dataset loader
- `src/train.py` — CodeBERT fine-tuning (Colab GPU)
- `src/evaluate.py` — metrics → `results/metrics.json`
- `scripts/inspect_dataset.py` — print splits, class balance, sample preview
- `src/predict.py` — inference
- `src/ingest.py` / `src/retriever.py` — RAG
- `src/pipeline.py` — end-to-end orchestration
- `api/main.py` — `POST /review`
- `app/streamlit_app.py` — demo UI

## Training (Colab T4)

**Local — inspect dataset:**

```powershell
python scripts\inspect_dataset.py
```

**Colab** — open `colab/train_codebert.ipynb`, enable T4 GPU, run all cells, download `codebert-vuln.zip`.

**Back on PC** — extract model:

```powershell
Expand-Archive -Path codebert-vuln.zip -DestinationPath models\ -Force
python scripts\verify_local_dev.py
```

Target metrics (after full training): **~93% accuracy**, **~0.92 F1** (varies by run).

Local smoke test (CPU, 200 train samples):

```powershell
python src\train.py --allow-cpu --max-samples 200 --epochs 1
```

## API example

```powershell
curl -X POST http://localhost:8000/review -H "Content-Type: application/json" -d "{\"code\": \"query = 'SELECT * FROM users WHERE id=' + user_id\", \"language\": \"python\"}"
```

## Resume bullet

> Built AI-powered code vulnerability detector — fine-tuned CodeBERT on 27k-sample Devign dataset (Hugging Face DetectVul/devign), RAG pipeline over OWASP Top 10 + CVE corpus using ChromaDB, LLaMA3-70B fix generation, deployed on HuggingFace Spaces.

## License

MIT — portfolio / educational use.
