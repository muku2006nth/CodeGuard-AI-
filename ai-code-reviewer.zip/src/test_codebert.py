from transformers import AutoTokenizer, AutoModel

print("Loading CodeBERT...")

tokenizer = AutoTokenizer.from_pretrained(
    "microsoft/codebert-base"
)

model = AutoModel.from_pretrained(
    "microsoft/codebert-base"
)

print("CodeBERT loaded successfully!")