"""CodeBERT inference for vulnerability classification."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

DEFAULT_MODEL = "microsoft/codebert-base"
VULN_LABELS = [
    "Safe",
    "SQL Injection",
    "Cross-Site Scripting (XSS)",
    "Buffer Overflow",
    "Command Injection",
    "Path Traversal",
    "Use After Free",
    "Other Vulnerability",
]


@dataclass
class ClassificationResult:
    is_vulnerable: bool
    vuln_type: str
    confidence: float
    label_id: int


class CodeBERTClassifier:
    def __init__(self, model_path: str | None = None, device: str | None = None):
        path = model_path or os.getenv("CODEBERT_MODEL_PATH", "models/codebert-vuln")
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")

        if Path(path).exists() and (Path(path) / "config.json").exists():
            self.tokenizer = AutoTokenizer.from_pretrained(path)
            self.model = AutoModelForSequenceClassification.from_pretrained(path)
        else:
            # Fallback: untrained base model (for dev before fine-tuning)
            self.tokenizer = AutoTokenizer.from_pretrained(DEFAULT_MODEL)
            self.model = AutoModelForSequenceClassification.from_pretrained(
                DEFAULT_MODEL, num_labels=2
            )

        self.model.to(self.device)
        self.model.eval()
        self.threshold = float(os.getenv("CONFIDENCE_THRESHOLD", "0.85"))

    def classify(self, code: str, max_length: int = 512) -> ClassificationResult:
        inputs = self.tokenizer(
            code,
            return_tensors="pt",
            truncation=True,
            max_length=max_length,
            padding=True,
        )
        inputs = {k: v.to(self.device) for k, v in inputs.items()}

        with torch.no_grad():
            outputs = self.model(**inputs)
            probs = torch.softmax(outputs.logits, dim=-1)
            label_id = int(probs.argmax(dim=-1).item())
            confidence = float(probs[0, label_id].item())

        num_labels = self.model.config.num_labels
        if num_labels == 2:
            is_vulnerable = label_id == 1 and confidence >= self.threshold
            vuln_type = "Potential Vulnerability" if is_vulnerable else "Safe"
        else:
            is_vulnerable = label_id != 0 and confidence >= self.threshold
            vuln_type = VULN_LABELS[label_id] if label_id < len(VULN_LABELS) else "Other Vulnerability"

        if not is_vulnerable and confidence < self.threshold:
            vuln_type = "Safe (low confidence)"

        return ClassificationResult(
            is_vulnerable=is_vulnerable,
            vuln_type=vuln_type,
            confidence=confidence,
            label_id=label_id,
        )


def predict_snippet(code: str, model_path: str | None = None) -> ClassificationResult:
    classifier = CodeBERTClassifier(model_path=model_path)
    return classifier.classify(code)
