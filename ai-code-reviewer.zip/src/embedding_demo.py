from transformers import AutoTokenizer, AutoModel
import torch

tokenizer = AutoTokenizer.from_pretrained(
    "microsoft/codebert-base"
)

model = AutoModel.from_pretrained(
    "microsoft/codebert-base"
)

code = """
query = "SELECT * FROM users WHERE id=" + user_input
"""

inputs = tokenizer(
    code,
    return_tensors="pt"
)

with torch.no_grad():
    outputs = model(**inputs)

print("Embedding Shape:")
print(outputs.last_hidden_state.shape)