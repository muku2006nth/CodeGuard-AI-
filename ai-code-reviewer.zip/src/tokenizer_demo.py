from transformers import AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained(
    "microsoft/codebert-base"
)

code = """
query = "SELECT * FROM users WHERE id=" + user_input
"""

tokens = tokenizer.tokenize(code)

print("TOKENS:")
print(tokens)

ids = tokenizer.encode(code)

print("\nTOKEN IDS:")
print(ids)