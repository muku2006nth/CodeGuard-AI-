from datasets import load_dataset
from transformers import (
    AutoTokenizer,
    AutoModelForSequenceClassification,
    TrainingArguments,
    Trainer
)

print("Loading dataset...")

dataset = load_dataset("DetectVul/devign")

tokenizer = AutoTokenizer.from_pretrained(
    "microsoft/codebert-base"
)

def tokenize(example):
    return tokenizer(
        example["func"],
        truncation=True,
        padding="max_length",
        max_length=512
    )

dataset = dataset.map(tokenize)

dataset = dataset.rename_column(
    "target",
    "labels"
)

model = AutoModelForSequenceClassification.from_pretrained(
    "microsoft/codebert-base",
    num_labels=2
)

training_args = TrainingArguments(
    output_dir="./results",
    num_train_epochs=1,
    per_device_train_batch_size=4,
    per_device_eval_batch_size=4,
    eval_strategy="epoch",
    save_strategy="epoch"
)

trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=dataset["train"],
    eval_dataset=dataset["validation"]
)

trainer.train()

model.save_pretrained(
    "./models/codebert-vuln"
)

print("Training Complete!")