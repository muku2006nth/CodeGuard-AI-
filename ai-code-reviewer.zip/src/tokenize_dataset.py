from datasets import load_dataset
from transformers import AutoTokenizer

print("Loading dataset...")

dataset = load_dataset("DetectVul/devign")

tokenizer = AutoTokenizer.from_pretrained(
    "microsoft/codebert-base"
)

def tokenize_function(example):
    return tokenizer(
        example["func"],
        truncation=True,
        padding="max_length",
        max_length=512
    )

tokenized_dataset = dataset.map(
    tokenize_function,
    batched=True
)

print(tokenized_dataset)