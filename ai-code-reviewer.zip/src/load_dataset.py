from datasets import load_dataset

print("Loading dataset...")

dataset = load_dataset("DetectVul/devign")

print(dataset)

print("\nFirst sample:")
print(dataset["train"][0])